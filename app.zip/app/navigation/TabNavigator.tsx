import React from 'react';
import { Platform, Image, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../home/HomeScreen';
import QuoteScreen from '../quote/QuoteScreen';
import ProfileScreen from '../profile/ProfileScreen';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          } else {
            iconName = 'home-outline';
          }

          return route.name !== 'Quote' ? (
            <Ionicons name={iconName} size={size} color={color} />
          ) : null;
        },
        tabBarActiveTintColor: '#45B3B4',
        tabBarInactiveTintColor: 'gray',
        tabBarHideOnKeyboard: false,
        tabBarStyle: {
          height: 70,
          paddingBottom: 10,
          paddingTop: 10,
          borderTopWidth: 0,
          elevation: 10,
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: -2,
          },
          shadowOpacity: 0.1,
          shadowRadius: 3,
          backgroundColor: 'white',
        },
        tabBarLabelStyle: {
          marginTop: -5,
          fontSize: 12,
        }
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen 
        name="Quote" 
        component={QuoteScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <View
              style={{
                flex: 1,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Image
                source={require('../../assets/RvK-logo.png')}
                style={{
                  width: 44,
                  height: 44,
                  tintColor: focused ? '#45B3B4' : 'black',
                }}
                resizeMode="contain"
              />
            </View>
          ),
          tabBarLabel: () => null,
        }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <Image
              source={require('../../assets/trainer-icon.png')}
              style={{
                width: 24,
                height: 24,
                tintColor: focused ? '#45B3B4' : 'gray',
              }}
              resizeMode="contain"
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
} 