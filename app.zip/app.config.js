export default {
  name: 'RvK',
  version: '1.0.0',
  extra: {
    pokemonApiKey: process.env.POKEMON_API_KEY,
  },
  // Enable New Architecture
  plugins: [
    [
      'expo-build-properties',
      {
        android: {
          newArchEnabled: true
        },
        ios: {
          newArchEnabled: true
        }
      }
    ]
  ]
}; 